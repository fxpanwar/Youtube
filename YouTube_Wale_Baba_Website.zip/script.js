// ====== EDIT THESE 3 VALUES ======
const UPI_ID = "YOUR-UPI@upi";
const WHATSAPP_NUMBER = "91XXXXXXXXXX"; // country code + number, no +
const QR_IMAGE = "qr-placeholder.svg";
// =================================

document.getElementById("upiText").textContent = UPI_ID;
document.getElementById("qrImage").src = QR_IMAGE;

function copyUPI(){
  navigator.clipboard.writeText(UPI_ID).then(()=>{
    const b=document.querySelector(".copy-btn");
    const old=b.textContent; b.textContent="Copied ✓";
    setTimeout(()=>b.textContent=old,1500);
  });
}

document.getElementById("screenshot").addEventListener("change", e=>{
  document.getElementById("fileName").textContent =
    e.target.files[0] ? e.target.files[0].name : "No file selected";
});

document.getElementById("paymentForm").addEventListener("submit", e=>{
  e.preventDefault();

  const phone=document.getElementById("phone").value.trim();
  if(!/^\d{10}$/.test(phone)){
    alert("Please enter a valid 10 digit WhatsApp number.");
    return;
  }

  // FRONT-END DEMO ONLY:
  // This does NOT verify whether ₹150 was actually received.
  // For production, send the form to your server/payment gateway,
  // verify payment server-side, then reveal the WhatsApp link.

  const message = encodeURIComponent(
    "Hello YouTube Wale Baba, maine ₹150 payment kiya hai. " +
    "Mera naam: " + document.getElementById("name").value.trim()
  );

  document.getElementById("whatsappBtn").href =
    "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + message;

  document.getElementById("success").classList.remove("hidden");
  document.getElementById("success").scrollIntoView({behavior:"smooth"});
});
